package com.salesianostriana.dam.proyectofinaljaimejimenez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalJaimeJimenezApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalJaimeJimenezApplication.class, args);
	}

}
