package com.salesianostriana.dam.proyectofinaljaimejimenez.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinaljaimejimenez.modelo.Pago;

public interface PagoRepository extends JpaRepository<Pago, Long>{

}
