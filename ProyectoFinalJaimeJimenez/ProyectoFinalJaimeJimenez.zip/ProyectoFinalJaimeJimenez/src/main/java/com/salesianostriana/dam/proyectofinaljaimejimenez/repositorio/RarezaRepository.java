package com.salesianostriana.dam.proyectofinaljaimejimenez.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinaljaimejimenez.modelo.Rareza;

public interface RarezaRepository extends JpaRepository<Rareza, Long>{

}
