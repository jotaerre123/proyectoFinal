package com.salesianostriana.dam.proyectofinaljaimejimenez.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinaljaimejimenez.modelo.Tipo;

public interface TipoRepository extends JpaRepository<Tipo, Long>{

}
