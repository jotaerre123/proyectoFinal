package com.salesianostriana.dam.proyectofinaljaimejimenez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalJaimeJimenezApplicationTests {

	@Test
	void contextLoads() {
	}

}
